"""Regenerate the three DGX notebooks:
  notebooks/ppq_data_pipeline.ipynb
  notebooks/ppq_training.ipynb
  notebooks/ppq_huggingface_data_pipeline.ipynb

Run: python tools/make_notebooks.py
"""
import json
from pathlib import Path

NB_DIR = Path(__file__).resolve().parents[1] / "notebooks"


def md(src: str) -> dict:
    return {"cell_type": "markdown", "metadata": {}, "source": src.strip().splitlines(keepends=True)}


def code(src: str) -> dict:
    return {"cell_type": "code", "execution_count": None, "metadata": {},
            "outputs": [], "source": src.strip().splitlines(keepends=True)}


def notebook(cells: list[dict]) -> dict:
    return {
        "cells": cells,
        "metadata": {
            "kernelspec": {"display_name": "Python 3", "language": "python", "name": "python3"},
            "language_info": {"name": "python", "version": "3.10"},
        },
        "nbformat": 4,
        "nbformat_minor": 5,
    }


# ===========================================================================
# Data pipeline notebook
# ===========================================================================

# Shared by both notebooks: clone/pull the two repos under names that match
# the config-cell defaults (/workspace/personaplex-qwen, /workspace/personaplex).
CLONE_CELL = code("""
# Clone or update the repos (first run downloads them; later runs git-pull).
# If the PPQ repo is private, use a token in the URL:
#   https://<TOKEN>@github.com/MoshiHead/personaplex-qwen-v1.git
import subprocess
from pathlib import Path

def clone_or_pull(url: str, dest: Path):
    if (dest / ".git").exists():
        print("already cloned:", dest, "- pulling latest")
        subprocess.run(["git", "-C", str(dest), "pull", "--ff-only"], check=False)
    else:
        subprocess.run(["git", "clone", url, str(dest)], check=True)
    print(dest, "->", subprocess.run(["git", "-C", str(dest), "rev-parse", "--short", "HEAD"],
                                     capture_output=True, text=True).stdout.strip())

# NOTE: the clone only has what you PUSHED to GitHub - commit/push local
# changes first or the box will run stale code.
clone_or_pull("https://github.com/MoshiHead/personaplex-qwen-v1.git",
              Path("/workspace/personaplex-qwen"))
clone_or_pull("https://github.com/NVIDIA/personaplex.git",
              Path("/workspace/personaplex"))
""")

DATA_CELLS = []

DATA_CELLS.append(md("""
# PPQ Data Pipeline

Run this notebook on your GPU box (defaults: 2x 32 GB cards). It:
1. Clones/updates the repos, sets up paths and dependencies (kokoro TTS, vLLM in its own venv).
2. Generates dialogue scripts with an instruct LLM (vLLM), then **stops the server**.
3. Launches one data worker per GPU for TTS + stereo stitching + Mimi tokenization.
4. Prepares Stage-A monologue data from LibriTTS-R (CC-BY-4.0).
5. Builds the stock PersonaPlex web client.

**Crash-safe resume everywhere.** Re-running any cell is safe:
- finished work is skipped (manifest is the source of truth, output names are
  stable global indices, `.npz` writes are atomic, torn manifests are repaired);
- per-shard append-only logs live in `DATA_ROOT/logs/worker-<stage>-<shard>.log`;
- every shard writes `logs/progress-<stage>-<shard>.json` with done/total/%/ETA,
  rendered by the *watch* cells below;
- dialogues that keep failing are retried up to `MAX_ATTEMPTS` times, then
  skipped and listed in `logs/failed-<stage>-<shard>.jsonl` (re-attempt them
  by launching the workers with `--retry-failed`).

For a **fresh start**, set `RESUME = False` and `FRESH_START_CONFIRM = "FRESH"`.
"""))

DATA_CELLS.append(CLONE_CELL)

DATA_CELLS.append(code("""
import os, sys, json, subprocess, time
from pathlib import Path

# ---- EDIT THESE ----
PPQ_REPO = "/workspace/personaplex-qwen"            # this repo (contains ppq/)
MOSHI_REPO = "/workspace/personaplex"              # original personaplex repo (moshi pkg inside)
MIMI_WEIGHT = "/workspace/models/mimi.safetensors" # moshi mimi codec weights
QWEN_TOKENIZER = "/workspace/models/qwen3-1.7b-base"  # local snapshot of Qwen/Qwen3-1.7B-Base
# Script-generator model: a local snapshot dir OR a HF repo id ("Qwen/Qwen3-8B",
# auto-downloaded by vLLM). On a 32 GB card, "Qwen/Qwen3-4B" also works well.
GEN_MODEL = "/workspace/models/qwen3-8b"
DATA_ROOT = Path("/workspace/ppq_data")
N_GPUS = 2                   # worker shards per stage; shard i is pinned to GPU i % N_PHYSICAL_GPUS
TARGET_SCRIPTS = 35000   # ~35k x ~80 s ~= 800 h of dialogue
MAX_ATTEMPTS = 3         # per-dialogue retry limit before it is skipped for good

RESUME = True                # False = archive previous outputs and start over
FRESH_START_CONFIRM = ""     # type "FRESH" here when RESUME = False
# --------------------

import torch
N_PHYSICAL_GPUS = max(1, torch.cuda.device_count())  # auto-detected
print(f"physical GPUs: {N_PHYSICAL_GPUS} | worker shards per stage: {N_GPUS}")
if N_GPUS > N_PHYSICAL_GPUS:
    print(f"note: {N_GPUS} shards share {N_PHYSICAL_GPUS} GPU(s) "
          "(shard i -> GPU i % N_PHYSICAL_GPUS)")

# Locate the repos (folder names may differ from the defaults, e.g. a GitHub
# clone named personaplex-qwen-v1). Fails loudly HERE, not at a later import.
def _locate_repo(preferred: str, marker: str, fallbacks=()) -> str:
    cands = [preferred, *fallbacks]
    for c in cands:
        if (Path(c) / marker).exists():
            return str(Path(c).resolve())
    raise FileNotFoundError(
        f"repo not found: none of {cands} contains {marker}. "
        "Set the correct path in the config cell above.")

PPQ_REPO = _locate_repo(PPQ_REPO, "ppq/__init__.py", [
    "/workspace/personaplex-qwen-v1",
    str(Path.home() / "personaplex-qwen"),
    str(Path.home() / "personaplex-qwen-v1"),
])
MOSHI_REPO = _locate_repo(MOSHI_REPO, "moshi/moshi/__init__.py", [
    "/workspace/personaplex-v1",
    str(Path.home() / "personaplex"),
])

os.environ["PYTHONPATH"] = f"{MOSHI_REPO}/moshi:{PPQ_REPO}:" + os.environ.get("PYTHONPATH", "")
for p in (f"{MOSHI_REPO}/moshi", PPQ_REPO):
    if p not in sys.path:
        sys.path.insert(0, p)

import importlib
importlib.invalidate_caches()
import ppq  # sanity check - if this fails, PPQ_REPO is still wrong
print("ppq", ppq.__version__, "from", ppq.__file__)

TOKENS_DIR = DATA_ROOT / "tokens"
SCRIPTS = DATA_ROOT / "scripts.jsonl"
LOG_DIR = DATA_ROOT / "logs"
DATA_ROOT.mkdir(parents=True, exist_ok=True)
LOG_DIR.mkdir(parents=True, exist_ok=True)

if not RESUME:
    assert FRESH_START_CONFIRM == "FRESH", "type FRESH to confirm a fresh start"
    stamp = time.strftime("%Y%m%d-%H%M%S")
    for p in (TOKENS_DIR, SCRIPTS, LOG_DIR):
        if p.exists():
            target = DATA_ROOT / f"archive-{p.name}-{stamp}"
            p.rename(target)
            print("archived", p, "->", target)
    LOG_DIR.mkdir(parents=True, exist_ok=True)

print("data root:", DATA_ROOT, "| logs:", LOG_DIR)
"""))

DATA_CELLS.append(md("""
## 1. Dependencies

kokoro (Apache-2.0) + misaki for TTS, espeak-ng for g2p, and a separate venv
for vLLM (its numpy pin conflicts with moshi).
"""))

DATA_CELLS.append(code("""
WORK = Path("/workspace")
KOKORO_DIR = WORK / "kokoro"
if not KOKORO_DIR.exists():
    subprocess.run(["git", "clone", "--depth", "1",
                    "https://github.com/hexgrad/kokoro.git", str(KOKORO_DIR)], check=True)
subprocess.run([sys.executable, "-m", "pip", "install", "-q", "-e", str(KOKORO_DIR)], check=True)
subprocess.run([sys.executable, "-m", "pip", "install", "-q",
    "misaki[en]", "soundfile", "pyloudnorm", "sphn", "safetensors",
    "datasets", "huggingface_hub", "requests"], check=True)
subprocess.run(["bash", "-c",
    "command -v espeak-ng || (apt-get update -qq && apt-get install -y -qq espeak-ng)"],
    check=False)
import kokoro, misaki  # noqa
print("kokoro ok:", kokoro.__file__)
"""))

DATA_CELLS.append(code("""
VENV = Path("/workspace/venvs/vllm_gen")
# vllm 0.10.2 is the last release whose bundled torch targets CUDA 12.8
# drivers (newer wheels abort with "NVIDIA driver too old" on cu128 drivers).
# transformers must stay at 4.56.x: newer releases removed
# PreTrainedTokenizer.all_special_tokens_extended, which vllm 0.10.2 calls.
# If you update the NVIDIA driver to 575+ (CUDA 12.9), you can unpin both.
VENV_PKGS = ["vllm==0.10.2", "transformers==4.56.2", "openai"]
_MARKER = VENV / ".ppq-pinned"
_WANT = ",".join(VENV_PKGS)
if not (VENV / "bin" / "python").exists():
    subprocess.run(["python3", "-m", "venv", str(VENV)], check=True)
if not _MARKER.exists() or _MARKER.read_text().strip() != _WANT:
    print("installing pinned packages into the venv (a few minutes)...")
    subprocess.run([str(VENV / "bin/pip"), "install", "-q", "--force-reinstall",
                    *VENV_PKGS], check=True)
    _MARKER.write_text(_WANT)
print("vllm venv:", VENV, VENV_PKGS)
"""))

DATA_CELLS.append(code("""
# Download the script-generator model (first run only).
# Skipped automatically when GEN_MODEL already exists locally or is a HF repo id.
if GEN_MODEL.startswith("/") and not Path(GEN_MODEL).exists():
    subprocess.run([sys.executable, "-m", "pip", "install", "-q", "-U",
                    "huggingface_hub"], check=True)
    from huggingface_hub import snapshot_download
    # if you point GEN_MODEL at a different model, change the repo_id here too
    snapshot_download(repo_id="Qwen/Qwen3-8B", local_dir=GEN_MODEL)
print("gen model ready:", GEN_MODEL)
"""))

DATA_CELLS.append(md("""
## 2. Dialogue script generation

Starts a vLLM server (on the last GPU) if the scripts file is incomplete,
generates the missing scripts, then the next cell **stops the server again**.
Resumable: re-running appends only the missing scripts; torn final lines from
an interrupted run are repaired automatically.
"""))

DATA_CELLS.append(code("""
import socket

def _script_count() -> int:
    if not SCRIPTS.exists():
        return 0
    with open(SCRIPTS, encoding="utf-8") as f:
        return sum(1 for line in f if line.strip())

def port_open(port: int = 8000) -> bool:
    with socket.socket() as s:
        return s.connect_ex(("127.0.0.1", port)) == 0

def resolve_model(spec: str) -> str:
    # Local snapshot dir if it exists, else a HF repo id (vLLM downloads it).
    p = Path(spec)
    if p.exists():
        assert (p / "config.json").exists(), \
            f"{p} has no config.json - not a model snapshot (incomplete download?)"
        return str(p)
    if not spec.startswith("/") and "/" in spec:
        print(f"'{spec}' not found locally - vLLM will download it from Hugging Face")
        return spec
    raise FileNotFoundError(
        f"model not found: {spec}\\n"
        "Either download it first, e.g.:\\n"
        f"  huggingface-cli download Qwen/Qwen3-8B --local-dir {spec}\\n"
        "or set GEN_MODEL = 'Qwen/Qwen3-8B' in the config cell and vLLM will "
        "download it automatically.")

if _script_count() >= TARGET_SCRIPTS:
    print("scripts already complete:", _script_count())
elif port_open(8000):
    print("vLLM server already running")
else:
    model = resolve_model(GEN_MODEL)
    # Kill zombie vLLM processes from previous crashed attempts - they hold
    # GPU memory and make the fresh server fail at engine init.
    subprocess.run(["pkill", "-f", "vllm.entrypoints"], check=False)
    time.sleep(3)
    # Last GPU; with a single GPU it shares GPU 0 - fine, nothing else runs
    # during script generation (the server is stopped before the audio workers).
    vllm_gpu = N_GPUS - 1
    srv_log = open(LOG_DIR / "vllm-server.log", "ab", buffering=0)
    proc = subprocess.Popen([
        str(VENV / "bin/python"), "-m", "vllm.entrypoints.openai.api_server",
        "--model", model, "--served-model-name", "qwen-gen",
        "--tensor-parallel-size", "1", "--max-model-len", "8192",
        # vLLM runs alone in this phase, so give it most of the card; 0.45 of a
        # 32 GB card is too small for an 8B bf16 model (~16 GB of weights).
        "--gpu-memory-utilization", "0.85", "--port", "8000",
    ], stdout=srv_log, stderr=subprocess.STDOUT, start_new_session=True,
       env={**os.environ, "CUDA_VISIBLE_DEVICES": str(vllm_gpu)})
    (LOG_DIR / "vllm-server.pid").write_text(str(proc.pid))
    print("vLLM starting (pid", proc.pid, ") on GPU", vllm_gpu, "- waiting for readiness...")
    for _ in range(360):   # up to 30 min (first run may download the model)
        if port_open(8000):
            break
        if proc.poll() is not None:   # server died - fail fast with the root cause
            lines = (LOG_DIR / "vllm-server.log").read_text(
                errors="replace").splitlines(keepends=True)
            # the real error is in the EngineCore subprocess, which logs BEFORE
            # the long APIServer wrapper traceback - center the window on it
            err = max((i for i, l in enumerate(lines) if "ERROR" in l),
                      default=max(0, len(lines) - 120))
            lo = max(0, min(err - 5, len(lines) - 120))
            tail = "".join(lines[lo:lo + 120])
            raise RuntimeError(
                "vLLM exited during startup. Log excerpt "
                "(also run nvidia-smi to check for zombie GPU memory):\\n" + tail)
        time.sleep(5)
    assert port_open(8000), "vLLM did not start; see logs/vllm-server.log"
    print("vLLM server up")
"""))

DATA_CELLS.append(code("""
from ppq.progress import setup_file_logger
from ppq.data.script_gen import generate_scripts_openai

existing = _script_count()
if existing >= TARGET_SCRIPTS:
    print("scripts already complete:", existing)
else:
    setup_file_logger("ppq.data.script_gen", LOG_DIR / "script-gen.log", reset=True)
    print(f"{existing} scripts exist; generating {TARGET_SCRIPTS - existing} more")
    print("(% progress + ETA are logged to logs/script-gen.log and printed below)")
    generate_scripts_openai(TARGET_SCRIPTS - existing, SCRIPTS, model="qwen-gen",
                            base_url="http://127.0.0.1:8000/v1", seed=existing)
print("total scripts:", _script_count())
"""))

DATA_CELLS.append(code("""
# Stop the vLLM server - script generation is done, free the GPU.
import signal

pid_file = LOG_DIR / "vllm-server.pid"
stopped = False
if pid_file.exists():
    try:
        os.killpg(int(pid_file.read_text().strip()), signal.SIGTERM)
        stopped = True
    except ProcessLookupError:
        pass
    pid_file.unlink(missing_ok=True)
if not stopped:
    subprocess.run(["pkill", "-f", "vllm.entrypoints"], check=False)
print("vLLM server stopped" if stopped else "pkill issued for vllm.entrypoints")
"""))

DATA_CELLS.append(code("""
from ppq.data.dialogue import Dialogue

n = n_back = n_int = n_pause = bad = 0
with open(SCRIPTS, encoding="utf-8") as f:
    for line in f:
        line = line.strip()
        if not line:
            continue
        try:
            d = Dialogue.from_dict(json.loads(line))
        except Exception:
            bad += 1
            continue
        n += 1
        n_back += sum(t.backchannel for t in d.turns)
        n_int += sum(t.interrupt for t in d.turns)
        n_pause += sum(t.pause_mid for t in d.turns)
print(f"{n} valid dialogues ({bad} bad lines skipped) | "
      f"backchannels {n_back} | interrupts {n_int} | mid-pauses {n_pause}")
"""))

DATA_CELLS.append(md("""
## 3. TTS + stereo stitching + Mimi tokenization (one worker per GPU)

First build the agent voice prompt (first seconds of a Kokoro voice), then
launch one detached worker per GPU. Each worker:
- processes scripts `i % N_GPUS == shard` and writes `conv-<global index>.npz`
  (names stay stable even if scripts.jsonl grows or the shard count changes);
- appends every finished dialogue to its manifest (the source of truth);
- writes `logs/worker-synth-<shard>.log` and `logs/progress-synth-<shard>.json`.

Re-running the launch cell is safe: shards with a live worker are left alone,
finished shards are skipped by the workers themselves, and a crashed shard
simply resumes where its manifest ends.
"""))

DATA_CELLS.append(code("""
import soundfile as sf
from ppq.data.tts_kokoro import KokoroTTS

VOICE_PROMPT_SECONDS = 8.0  # matches the worker's --voice-prompt-seconds default
VOICE_PROMPT = DATA_ROOT / "voice_prompt_agent.wav"
if not VOICE_PROMPT.exists():
    tts = KokoroTTS()
    res = tts.synth(
        "Hello there! It is lovely to chat with you today. "
        "I am always happy to help with whatever is on your mind, "
        "so feel free to ask me anything at all.", voice="af_heart")
    n = int(VOICE_PROMPT_SECONDS * 24000)
    sf.write(VOICE_PROMPT, res.wav[:n], 24000)
print("voice prompt:", VOICE_PROMPT, f"({VOICE_PROMPT_SECONDS}s)")
"""))

DATA_CELLS.append(code("""
from ppq.progress import pid_alive, pipeline_all_done, render_data_progress

def launch_workers(stage: str, extra_args=()):
    launched, running = [], []
    for shard in range(N_GPUS):
        pid_file = LOG_DIR / f"worker-{stage}-{shard:04d}.pid"
        if pid_file.exists():
            try:
                pid = int(pid_file.read_text().strip())
            except ValueError:
                pid = -1
            if pid > 0 and pid_alive(pid):
                running.append(shard)
                continue
        console = open(LOG_DIR / f"worker-{stage}-{shard:04d}.console.log", "ab", buffering=0)
        cmd = [sys.executable, "-m", "ppq.data.worker",
               "--stage", stage, "--shard", str(shard), "--num-shards", str(N_GPUS),
               "--out", str(TOKENS_DIR), "--log-dir", str(LOG_DIR),
               "--mimi-weight", MIMI_WEIGHT, "--tokenizer", QWEN_TOKENIZER,
               "--max-attempts", str(MAX_ATTEMPTS), "--seed", "0", *extra_args]
        gpu = shard % N_PHYSICAL_GPUS  # share GPUs when shards > physical GPUs
        subprocess.Popen(cmd, env={**os.environ, "CUDA_VISIBLE_DEVICES": str(gpu)},
                         stdout=console, stderr=subprocess.STDOUT,
                         start_new_session=True)
        launched.append(shard)
    print(f"{stage}: launched shards {launched} | already running {running}")
    if running:
        print("(safe: live workers are never duplicated)")

if pipeline_all_done(LOG_DIR, ("synth",)):
    print("synth stage already complete")
    print(render_data_progress(LOG_DIR, ("synth",)))
else:
    launch_workers("synth", ["--scripts", str(SCRIPTS),
                             "--voice-prompt", str(VOICE_PROMPT)])
"""))

DATA_CELLS.append(code("""
# Live progress table - refreshes until all synth shards finish.
# Interrupt the cell to stop watching (workers keep running); re-run any time.
from ppq.progress import watch
watch(LOG_DIR, ("synth",), interval_s=60)
"""))

DATA_CELLS.append(code("""
# Last lines of each shard log (failures show up here with a full traceback).
for shard in range(N_GPUS):
    p = LOG_DIR / f"worker-synth-{shard:04d}.log"
    if p.exists():
        lines = p.read_text(encoding="utf-8", errors="replace").splitlines()
        print(f"--- shard {shard} (last 3 lines) ---")
        print("\\n".join(lines[-3:]))
"""))

DATA_CELLS.append(md("""
## 4. Stage A: LibriTTS-R monologues (~100 h, CC-BY-4.0)

Same worker pattern as the synth stage. The % shown for libritts is an
estimate (the corpus streams until the hour budget is reached); audio hours
in the table are exact.
"""))

DATA_CELLS.append(code("""
if pipeline_all_done(LOG_DIR, ("libritts",)):
    print("libritts stage already complete")
    print(render_data_progress(LOG_DIR, ("libritts",)))
else:
    launch_workers("libritts", ["--max-hours", "100"])
"""))

DATA_CELLS.append(code("""
from ppq.progress import watch
watch(LOG_DIR, ("libritts",), interval_s=60)
"""))

DATA_CELLS.append(md("""
## 5. Aggregate stats
"""))

DATA_CELLS.append(code("""
from ppq.progress import read_jsonl, repair_jsonl

n_synth = n_libritts = 0
total_s = 0.0
bc = ic = mp = words = 0
for m in sorted(TOKENS_DIR.glob("manifest*.jsonl")):
    repair_jsonl(m)
    for e in read_jsonl(m):
        if e.get("source") == "libritts":
            n_libritts += 1
            total_s += e["frames"] / 12.5
        else:
            n_synth += 1
            total_s += e.get("duration_s", e["frames"] / 12.5)
            bc += e.get("backchannels", 0)
            ic += e.get("interrupts", 0)
            mp += e.get("mid_pauses", 0)
            words += e.get("words_estimated", 0)
print(f"synth dialogues     : {n_synth}")
print(f"libritts monologues : {n_libritts}")
print(f"total audio         : {total_s / 3600:.1f} h")
print(f"backchannels {bc} | interrupts {ic} | mid-pauses {mp} | est words {words}")
"""))

DATA_CELLS.append(md("""
## 6. Web client

Build the stock PersonaPlex web client (unchanged - the PPQ server speaks the
same WebSocket protocol).
"""))

DATA_CELLS.append(code("""
CLIENT = Path(MOSHI_REPO) / "client"
if not (CLIENT / "dist").exists():
    subprocess.run(["npm", "install"], cwd=CLIENT, check=True)
    subprocess.run(["npm", "run", "build"], cwd=CLIENT, check=True)
print("client dist:", CLIENT / "dist")
"""))


# ===========================================================================
# Training notebook
# ===========================================================================

TRAIN_CELLS = []

TRAIN_CELLS.append(md("""
# PPQ Training

Run after `ppq_data_pipeline.ipynb` on a multi-GPU box (defaults are tuned
for 2x 32 GB cards, e.g. RTX 5090; scale `N_GPUS`/`batch_size` up on bigger
hardware). Stages:
1. Build the initial checkpoint: Qwen backbone weights + transplanted depformer.
2. Stage A — audio-side warmup (backbone frozen).
3. Stage B — full fine-tuning.
4. Evaluation (per-codebook loss + offline generation).
5. Serving with the stock PersonaPlex web UI.

**Crash-safe resume, on by default.** Each stage has its own directory
(`stage_a/`, `stage_b/`); re-running a launch cell:
- exits immediately when `checkpoints/final` is complete;
- resumes from the newest complete step checkpoint (model + optimizer +
  scheduler + RNG) otherwise — a crash costs at most `save_every_minutes` of work;
- never starts a second copy while a run is still alive.

Training logs (append-only) are in `<stage>/logs/train.log`; live
step/%/ETA status is in `<stage>/progress.json`, rendered by the watch cells.
To restart a stage from scratch, delete its `checkpoints/` directory.

> Note: after a resume the data order is reshuffled (reseeded), so resumed
> runs are equivalent, not bit-identical. Optimizer/scheduler/RNG states are
> restored exactly.
"""))

TRAIN_CELLS.append(CLONE_CELL)

TRAIN_CELLS.append(code("""
import subprocess, sys
subprocess.run([sys.executable, "-m", "pip", "install", "-q",
    "huggingface_hub", "safetensors", "einops", "sphn", "peft",
    "soundfile", "kokoro>=0.9", "misaki[en]", "pyloudnorm"], check=True)
print("deps ok")
"""))

TRAIN_CELLS.append(code("""
import os, sys, json, subprocess
from pathlib import Path

# ---- EDIT THESE ----
PPQ_REPO = "/workspace/personaplex-qwen"
MOSHI_REPO = "/workspace/personaplex"
MIMI_WEIGHT = "/workspace/models/mimi.safetensors"
QWEN_BASE = "/workspace/models/qwen3-1.7b-base"        # local Qwen3-1.7B-Base snapshot
PERSONAPLEX_CKPT = "/workspace/models/personaplex/model.sft"  # personaplex LM (depformer donor)
DATA_ROOT = Path("/workspace/ppq_data")
TOKENS_DIR = DATA_ROOT / "tokens"
RUN_DIR = Path("/workspace/ppq_runs/run2")  # run1 = video-21h trial; fresh dir = clean LR schedule
N_GPUS = 2                   # training ranks; auto-clamped to the physical GPU count
# --------------------

import torch
N_PHYSICAL_GPUS = max(1, torch.cuda.device_count())  # auto-detected
if N_GPUS > N_PHYSICAL_GPUS:
    # DDP ranks pin local_rank -> cuda:local_rank, so ranks cannot share a GPU.
    print(f"note: N_GPUS={N_GPUS} clamped to {N_PHYSICAL_GPUS} physical GPU(s)")
    N_GPUS = N_PHYSICAL_GPUS
print(f"physical GPUs: {N_PHYSICAL_GPUS} | training ranks: {N_GPUS}")

# Locate the repos (folder names may differ from the defaults, e.g. a GitHub
# clone named personaplex-qwen-v1). Fails loudly HERE, not at a later import.
def _locate_repo(preferred: str, marker: str, fallbacks=()) -> str:
    cands = [preferred, *fallbacks]
    for c in cands:
        if (Path(c) / marker).exists():
            return str(Path(c).resolve())
    raise FileNotFoundError(
        f"repo not found: none of {cands} contains {marker}. "
        "Set the correct path in the config cell above.")

PPQ_REPO = _locate_repo(PPQ_REPO, "ppq/__init__.py", [
    "/workspace/personaplex-qwen-v1",
    str(Path.home() / "personaplex-qwen"),
    str(Path.home() / "personaplex-qwen-v1"),
])
MOSHI_REPO = _locate_repo(MOSHI_REPO, "moshi/moshi/__init__.py", [
    "/workspace/personaplex-v1",
    str(Path.home() / "personaplex"),
])

os.environ["PYTHONPATH"] = f"{MOSHI_REPO}/moshi:{PPQ_REPO}:" + os.environ.get("PYTHONPATH", "")
for p in (f"{MOSHI_REPO}/moshi", PPQ_REPO):
    if p not in sys.path:
        sys.path.insert(0, p)

import importlib
importlib.invalidate_caches()
import ppq  # sanity check - if this fails, PPQ_REPO is still wrong
print("ppq", ppq.__version__, "from", ppq.__file__)

CLIENT_DIST = Path(MOSHI_REPO) / "client" / "dist"
STAGE_A_DIR = RUN_DIR / "stage_a"
STAGE_B_DIR = RUN_DIR / "stage_b"
RUN_DIR.mkdir(parents=True, exist_ok=True)
"""))

TRAIN_CELLS.append(code("""
# Download the model files training needs (idempotent - skips what exists).
# - FULL Qwen3-1.7B-Base weights (~3.4 GB; the HF data notebook fetched only
#   the tokenizer files, which are enough for tokenization but not training).
# - PersonaPlex LM checkpoint (depformer donor; gated repo - needs HF_TOKEN).
# - mimi codec weights (only if the data notebook did not fetch them already).
import getpass, shutil
from huggingface_hub import hf_hub_download, snapshot_download

if not os.environ.get("HF_TOKEN"):
    os.environ["HF_TOKEN"] = getpass.getpass(
        "HF token (for nvidia/personaplex-7b-v1): ")

if not list(Path(QWEN_BASE).glob("*.safetensors")):
    snapshot_download(repo_id="Qwen/Qwen3-1.7B-Base", local_dir=QWEN_BASE)
print("qwen weights:", QWEN_BASE)

Path(PERSONAPLEX_CKPT).parent.mkdir(parents=True, exist_ok=True)
if not Path(PERSONAPLEX_CKPT).exists():
    src = None
    for name in ("model.sft", "model.safetensors"):
        try:
            src = hf_hub_download("nvidia/personaplex-7b-v1", name,
                                  token=os.environ["HF_TOKEN"])
            break
        except Exception:
            continue
    if src is None:
        raise RuntimeError(
            "no LM weights found in nvidia/personaplex-7b-v1 - "
            "accept the model license on its HF page first")
    shutil.copy(src, PERSONAPLEX_CKPT)
print("personaplex ckpt:", PERSONAPLEX_CKPT,
      f"({Path(PERSONAPLEX_CKPT).stat().st_size / 2**30:.1f} GiB)")

Path(MIMI_WEIGHT).parent.mkdir(parents=True, exist_ok=True)
if not Path(MIMI_WEIGHT).exists():
    src = hf_hub_download("nvidia/personaplex-7b-v1",
                          "tokenizer-e351c8d8-checkpoint125.safetensors",
                          token=os.environ["HF_TOKEN"])
    shutil.copy(src, MIMI_WEIGHT)
print("mimi:", MIMI_WEIGHT)
"""))

TRAIN_CELLS.append(code("""
# Where are we? (safe to re-run any time)
from ppq.progress import training_status
print(training_status(RUN_DIR))
"""))

TRAIN_CELLS.append(md("""
## 1. Initial checkpoint
Qwen3-1.7B-Base backbone + transplanted PersonaPlex depformer; fresh audio
embeddings, depformer_in, depformer_text_emb (trained in stage A).
"""))

TRAIN_CELLS.append(code("""
import torch
from ppq.config import PPQModelConfig
from ppq.checkpoint import build_model_from_scratch, is_complete, save_pretrained

INIT_DIR = RUN_DIR / "init"
if is_complete(INIT_DIR):
    print("init checkpoint already complete:", INIT_DIR)
else:
    cfg = PPQModelConfig()
    model = build_model_from_scratch(cfg, qwen_dir=QWEN_BASE,
                                     depformer_source=PERSONAPLEX_CKPT)
    save_pretrained(model, INIT_DIR)   # atomic + COMPLETE marker
    del model
    print("init checkpoint saved:", INIT_DIR)
"""))

TRAIN_CELLS.append(md("""
## 2. Stage A — audio-side warmup
Backbone layers, final norm and text head frozen; everything else trains.
"""))

TRAIN_CELLS.append(code("""
from ppq.config import PPQModelConfig, TrainConfig

STAGE_A_DIR.mkdir(parents=True, exist_ok=True)
tcfg_a = TrainConfig(
    model=PPQModelConfig(),
    data_dir=str(TOKENS_DIR),
    output_dir=str(STAGE_A_DIR),
    init_checkpoint=str(RUN_DIR / "init"),
    stage="a_audio_warmup",
    # 32 GB cards: batch_size=1 + grad checkpointing (the depformer runs
    # 1250 sequential frames, so activations dominate memory). On 80 GB cards
    # use batch_size=4, grad_accum=1. Effective batch = batch x accum x N_GPUS.
    # Still OOM? Lower segment_frames (e.g. 750 = 60 s) - crops are random.
    batch_size=1, grad_accum=4,
    max_steps=2000,              # ~= 2000 x (4 x N_GPUS) x 100 s of audio seen
    save_every=200, save_every_minutes=30, keep_last_k=3,
    log_every=10,
    fsdp=False,                  # DDP; resume of optimizer state needs fsdp=False
    gradient_checkpointing=True,
)
tcfg_a.to_json(STAGE_A_DIR / "config.json")
print(STAGE_A_DIR / "config.json")
"""))

TRAIN_CELLS.append(code("""
from ppq.checkpoint import is_complete
from ppq.progress import pid_alive

def launch_stage(stage_dir: Path):
    logs = stage_dir / "logs"
    logs.mkdir(parents=True, exist_ok=True)
    pid_file = logs / "torchrun.pid"
    if is_complete(stage_dir / "checkpoints" / "final"):
        print(stage_dir.name, "already finished (final checkpoint complete)")
        return
    if pid_file.exists():
        try:
            pid = int(pid_file.read_text().strip())
        except ValueError:
            pid = -1
        if pid > 0 and pid_alive(pid):
            print(stage_dir.name, "is already running - just watch it below")
            return
    # reduces allocator fragmentation on long runs (OOM-message recommendation)
    os.environ["PYTORCH_CUDA_ALLOC_CONF"] = "expandable_segments:True"
    console = open(logs / "console.log", "ab", buffering=0)
    proc = subprocess.Popen([
        "torchrun", "--nproc_per_node", str(N_GPUS), "--max-restarts", "3",
        "-m", "ppq.train.train", "--config", str(stage_dir / "config.json"),
    ], stdout=console, stderr=subprocess.STDOUT, start_new_session=True)
    pid_file.write_text(str(proc.pid))
    print(stage_dir.name, "launched (pid", proc.pid,
          ") - auto-resume picks up from the last checkpoint")

launch_stage(STAGE_A_DIR)
"""))

TRAIN_CELLS.append(code("""
# Live training progress - refreshes until the stage finishes.
# Interrupt the cell to stop watching (training keeps running); re-run any time.
from ppq.progress import watch_train
watch_train(STAGE_A_DIR, interval_s=60)
"""))

TRAIN_CELLS.append(md("""
## 3. Stage B — full fine-tuning
All weights trainable (backbone at 0.5x LR, depformer at 1.5x LR), starting
from Stage A's final checkpoint. Auto-resumes from its own checkpoints.
"""))

TRAIN_CELLS.append(code("""
assert is_complete(STAGE_A_DIR / "checkpoints" / "final"), "finish Stage A first"

STAGE_B_DIR.mkdir(parents=True, exist_ok=True)
tcfg_b = TrainConfig(
    model=PPQModelConfig(),
    data_dir=str(TOKENS_DIR),
    output_dir=str(STAGE_B_DIR),
    init_checkpoint=str(STAGE_A_DIR / "checkpoints" / "final"),
    stage="b_full",
    # 32 GB cards: batch_size=1 + grad checkpointing. 80 GB cards: batch_size=4,
    # grad_accum=1. Still OOM? Lower segment_frames (e.g. 750 = 60 s).
    batch_size=1, grad_accum=4,
    max_steps=10000,             # ~5-7 epochs over the full 4-source dataset.
                                 # Set BEFORE launch - the cosine LR schedule is
                                 # derived from max_steps, changing it mid-run rescales LR.
    lr=5e-6, backbone_lr_mult=0.5, depformer_lr_mult=1.5,
    lora_rank=64,
    save_every=250, save_every_minutes=30, keep_last_k=3,
    log_every=10,
    fsdp=False,
    gradient_checkpointing=True,
)
tcfg_b.to_json(STAGE_B_DIR / "config.json")
print(STAGE_B_DIR / "config.json")
"""))

TRAIN_CELLS.append(code("""
launch_stage(STAGE_B_DIR)
"""))

TRAIN_CELLS.append(code("""
from ppq.progress import watch_train
watch_train(STAGE_B_DIR, interval_s=120)
"""))

TRAIN_CELLS.append(md("""
## 4. Evaluation
Per-codebook cross-entropy on held-out segments, then an offline full-duplex
generation against a recorded user utterance (or synthesized one).
"""))

TRAIN_CELLS.append(code("""
import glob, torch
from ppq.checkpoint import load_pretrained
from ppq.data.dataset import TokenShardDataset, collate
from ppq.train.evaluate import eval_per_codebook

FINAL_B = STAGE_B_DIR / "checkpoints" / "final"
assert is_complete(FINAL_B), "finish Stage B first"

device = "cuda"
model = load_pretrained(FINAL_B, device=device)
manifests = sorted(glob.glob(str(TOKENS_DIR / "manifest*.jsonl")))  # all sources + shards
print(f"eval manifests: {len(manifests)}")
ds = TokenShardDataset(manifests, model.cfg, segment_frames=1250, seed=999)
loader = torch.utils.data.DataLoader(ds, batch_size=4, collate_fn=collate, drop_last=True)
losses = eval_per_codebook(model, loader, n_batches=8, device=device, mcfg=model.cfg)
print({k: round(v, 3) for k, v in losses.items()})
del model
torch.cuda.empty_cache()
"""))

TRAIN_CELLS.append(code("""
import numpy as np
from ppq.checkpoint import get_mimi, load_pretrained
from ppq.text_tokenizer import QwenTextTokenizer
from ppq.train.evaluate import generate_offline, write_wav, response_delays

device = "cuda"
model = load_pretrained(FINAL_B, device=device)
mimi = get_mimi(MIMI_WEIGHT, device)
tokenizer = QwenTextTokenizer(QWEN_BASE, model.cfg)

USER_WAV = DATA_ROOT / "test_user.wav"   # record your own 24 kHz wav, or synthesize:
if not USER_WAV.exists():
    from ppq.data.tts_kokoro import KokoroTTS
    import soundfile as sf
    res = KokoroTTS().synth(
        "Hey! Tell me a fun fact about the ocean in one or two sentences.",
        voice="am_adam")
    sf.write(USER_WAV, res.wav, 24000)

import sphn
user_wav, sr = sphn.read(str(USER_WAV))
if sr != 24000:
    user_wav = sphn.resample(user_wav, sr, 24000)

VP_WAV = DATA_ROOT / "voice_prompt_agent.wav"
if not VP_WAV.exists():
    # The HF pipeline sources with voice_prompt=none (e.g. video-21h) never
    # create an agent voice prompt - synthesize one so this cell works.
    from ppq.data.tts_kokoro import KokoroTTS
    import soundfile as sf
    res = KokoroTTS().synth(
        "Hi there! I'm your assistant. It's really great to meet you today.",
        voice="af_heart")
    sf.write(VP_WAV, res.wav, 24000)
    print("synthesized fallback voice prompt:", VP_WAV)
vp_wav, vp_sr = sphn.read(str(VP_WAV))
if vp_sr != 24000:
    vp_wav = sphn.resample(vp_wav, vp_sr, 24000)

agent_wav, transcript = generate_offline(
    model, mimi, tokenizer, user_wav[0].astype(np.float32),
    vp_wav[0].astype(np.float32),
    "You are a cheerful, helpful assistant. You speak naturally.",
    device=device, max_seconds=30.0)
write_wav(str(RUN_DIR / "agent_reply.wav"), agent_wav)
print("transcript:", transcript)
print("response delays (s):", response_delays(agent_wav, user_wav[0]))
"""))

TRAIN_CELLS.append(md("""
## 5. Serving

Stock PersonaPlex WebSocket protocol + the stock web client. Point your
reverse proxy / browser at the printed port.
"""))

TRAIN_CELLS.append(code("""
cmd = [
    sys.executable, "-m", "ppq.serve.server",
    "--ppq-checkpoint", str(STAGE_B_DIR / "checkpoints" / "final"),
    "--mimi-weight", MIMI_WEIGHT,
    "--tokenizer", QWEN_BASE,
    "--voice-prompt-dir", str(DATA_ROOT),   # dir containing voice_prompt_agent.wav
    "--default-voice", "voice_prompt_agent.wav",
    "--static", str(CLIENT_DIST),
    "--port", "8998",
]
print(" ".join(cmd))
# subprocess.Popen(cmd)   # uncomment to launch
"""))


# ===========================================================================
# Hugging Face real-conversation data notebook
# ===========================================================================

HF_CELLS = []

HF_CELLS.append(md("""
# PPQ Hugging Face Data Pipeline (real conversations)

Turns the four gated **otoearth otoSpeech** datasets into PPQ training tokens
(`codes [17,T]` + `loss_mask` npz samples + `manifest-real-*.jsonl` in
`DATA_ROOT/tokens`, the same format the synth pipeline writes):

| source | HF repo | license | transcripts | voice prompt |
|---|---|---|---|---|
| video-21h | otoearth/otoSpeech-video-full-duplex-21h | custom (no redistribution, no voice cloning) | bundled word timestamps | none |
| task-20h | otoearth/otoSpeech-full-duplex-task-oriented-20h | CC BY 4.0 | Whisper ASR (this notebook) | same speaker |
| task-v2 | otoearth/otoSpeech-full-duplex-task-oriented-v2 | CC BY 4.0 | Whisper ASR (this notebook) | same speaker |
| turn-104h | otoearth/otoSpeech-full-duplex-turn-104h | research use, Voice Identity clause | SRT + Whisper for long segments | none |

**Before running:** accept the gated terms on each dataset page with the same
HF account whose token you paste below. Redacted segments are kept as audio
context but their loss is zeroed; video/turn samples are built WITHOUT a voice
prompt (license); task samples use a same-speaker prompt clip (CC BY 4.0,
attribution required).

Stages (one worker per GPU, crash-safe resume like the synth pipeline):
1. `asr` — warms the Whisper word cache for the CC-BY task sets (resumable).
2. `real` — streams sessions over HTTP range reads (no full tar downloads;
   video MP4s and turn combined_audio.wav are never fetched), chunks at mutual
   silence into 20-80 s segments, tokenizes with Mimi, writes samples.

Audio is loudness-normalized per channel; sessions with < 12 dB channel
separation (cross-talk) are skipped. Watch cells show done/total/%/ETA per
shard; failures land in `logs/failed-<stage>-<source>-<shard>.jsonl`.
"""))

HF_CELLS.append(CLONE_CELL)

HF_CELLS.append(code("""
import os, sys, json, subprocess, time
from pathlib import Path

# ---- EDIT THESE ----
PPQ_REPO = "/workspace/personaplex-qwen"            # this repo (contains ppq/)
MOSHI_REPO = "/workspace/personaplex"              # original personaplex repo (moshi pkg inside)
MIMI_WEIGHT = "/workspace/models/mimi.safetensors" # moshi mimi codec weights
QWEN_TOKENIZER = "/workspace/models/qwen3-1.7b-base"  # local snapshot of Qwen/Qwen3-1.7B-Base
DATA_ROOT = Path("/workspace/ppq_data")
N_GPUS = 2                   # worker shards per stage; shard i is pinned to GPU i % N_PHYSICAL_GPUS
SELECTED_SOURCES = ["task-20h", "task-v2", "video-21h", "turn-104h"]
ASR_MODEL = "openai/whisper-large-v3-turbo"
MAX_ATTEMPTS = 3             # per-session retry limit before it is skipped for good

RESUME = True                # False = archive previous HF-pipeline outputs and start over
FRESH_START_CONFIRM = ""     # type "FRESH" here when RESUME = False
# --------------------

import torch
N_PHYSICAL_GPUS = max(1, torch.cuda.device_count())  # auto-detected
print(f"physical GPUs: {N_PHYSICAL_GPUS} | worker shards per stage: {N_GPUS}")
if N_GPUS > N_PHYSICAL_GPUS:
    print(f"note: {N_GPUS} shards share {N_PHYSICAL_GPUS} GPU(s) "
          "(shard i -> GPU i % N_PHYSICAL_GPUS)")

def _locate_repo(preferred: str, marker: str, fallbacks=()) -> str:
    cands = [preferred, *fallbacks]
    for c in cands:
        if (Path(c) / marker).exists():
            return str(Path(c).resolve())
    raise FileNotFoundError(
        f"repo not found: none of {cands} contains {marker}. "
        "Set the correct path in the config cell above.")

PPQ_REPO = _locate_repo(PPQ_REPO, "ppq/__init__.py", [
    "/workspace/personaplex-qwen-v1",
    str(Path.home() / "personaplex-qwen"),
    str(Path.home() / "personaplex-qwen-v1"),
])
MOSHI_REPO = _locate_repo(MOSHI_REPO, "moshi/moshi/__init__.py", [
    "/workspace/personaplex-v1",
    str(Path.home() / "personaplex"),
])

os.environ["PYTHONPATH"] = f"{MOSHI_REPO}/moshi:{PPQ_REPO}:" + os.environ.get("PYTHONPATH", "")
for p in (f"{MOSHI_REPO}/moshi", PPQ_REPO):
    if p not in sys.path:
        sys.path.insert(0, p)

import importlib
importlib.invalidate_caches()
import ppq  # sanity check - if this fails, PPQ_REPO is still wrong
print("ppq", ppq.__version__, "from", ppq.__file__)

TOKENS_DIR = DATA_ROOT / "tokens"
LOG_DIR = DATA_ROOT / "logs"
DATA_ROOT.mkdir(parents=True, exist_ok=True)
LOG_DIR.mkdir(parents=True, exist_ok=True)

if not RESUME:
    assert FRESH_START_CONFIRM == "FRESH", "type FRESH to confirm a fresh start"
    stamp = time.strftime("%Y%m%d-%H%M%S")
    for name in ("markers", "asr_cache", "raw", "hf_cache"):
        p = DATA_ROOT / name
        if p.exists():
            target = DATA_ROOT / f"archive-{p.name}-{stamp}"
            p.rename(target)
            print("archived", p, "->", target)
    for m in TOKENS_DIR.glob("manifest-real-*.jsonl"):
        for line in m.read_text(encoding="utf-8").splitlines():
            try:
                f = Path(json.loads(line).get("path", ""))
            except json.JSONDecodeError:
                continue
            if f.exists():
                f.unlink()
        m.unlink()
        print("removed", m)

print("data root:", DATA_ROOT, "| logs:", LOG_DIR, "| sources:", SELECTED_SOURCES)
"""))

HF_CELLS.append(md("""
## 1. Dependencies + HF token
"""))

HF_CELLS.append(code("""
subprocess.run([sys.executable, "-m", "pip", "install", "-q",
    "soundfile", "pyloudnorm", "sphn", "safetensors", "einops",
    "huggingface_hub", "requests", "transformers>=4.56", "accelerate"], check=True)
import soundfile, transformers, einops  # noqa
print("deps ok: transformers", transformers.__version__)
"""))

HF_CELLS.append(code("""
# HF token with access to the four gated otoearth datasets (input hidden).
# The token is only kept in this kernel's HF_TOKEN env var - never written to disk.
import getpass
from huggingface_hub import HfApi
from ppq.data.oto_sources import SOURCES

if not os.environ.get("HF_TOKEN"):
    os.environ["HF_TOKEN"] = getpass.getpass("HF token: ")
api = HfApi(token=os.environ["HF_TOKEN"])
for name in SELECTED_SOURCES:
    spec = SOURCES[name]
    info = api.dataset_info(spec.repo_id)  # raises if the gated terms are not accepted
    print(f"OK  {name:<10} {spec.repo_id} (gated={info.gated})")
"""))

HF_CELLS.append(code("""
# Download the model files the workers need (idempotent - skips what exists).
# mimi: the moshi codec weights from the personaplex repo (gated - uses HF_TOKEN).
# qwen: tokenizer files only (a few MB; the 1.7B weights are NOT needed here).
import shutil
from huggingface_hub import hf_hub_download, snapshot_download

Path(MIMI_WEIGHT).parent.mkdir(parents=True, exist_ok=True)
if not Path(MIMI_WEIGHT).exists():
    src = hf_hub_download("nvidia/personaplex-7b-v1",
                          "tokenizer-e351c8d8-checkpoint125.safetensors",
                          token=os.environ.get("HF_TOKEN"))
    shutil.copy(src, MIMI_WEIGHT)
print("mimi:", MIMI_WEIGHT,
      f"({Path(MIMI_WEIGHT).stat().st_size / 2**20:.0f} MiB)")

if not (Path(QWEN_TOKENIZER) / "tokenizer.json").exists():
    snapshot_download(repo_id="Qwen/Qwen3-1.7B-Base", local_dir=QWEN_TOKENIZER,
                      allow_patterns=["*.json", "*.txt"])
print("qwen tokenizer:", QWEN_TOKENIZER)
"""))

HF_CELLS.append(code("""
# What will be built, per source (license-driven choices are baked into SOURCES).
from ppq.data.oto_sources import SOURCES

for name in SELECTED_SOURCES:
    s = SOURCES[name]
    print(f"{s.name:<10} kind={s.kind:<6} asr={s.asr_mode:<14} "
          f"voice_prompt={s.voice_prompt_mode:<12} license={s.license}")
    print(f"  {s.license_note}")
"""))

HF_CELLS.append(md("""
## 2. Worker launcher (shared by both stages)

Same pattern as the synth pipeline: one detached worker per GPU, PID-file
guarded, append-only logs, per-shard progress JSON. Re-running a launch cell
never duplicates a live worker; crashed shards resume where they stopped.
"""))

HF_CELLS.append(code("""
from ppq.progress import pid_alive, pipeline_all_done, render_data_progress

def launch_hf_workers(stage: str, source: str, extra_args=()):
    launched, running = [], []
    for shard in range(N_GPUS):
        pid_file = LOG_DIR / f"worker-{stage}-{source}-{shard:04d}.pid"
        if pid_file.exists():
            try:
                pid = int(pid_file.read_text().strip())
            except ValueError:
                pid = -1
            if pid > 0 and pid_alive(pid):
                running.append(shard)
                continue
        console = open(LOG_DIR / f"worker-{stage}-{source}-{shard:04d}.console.log",
                       "ab", buffering=0)
        cmd = [sys.executable, "-m", "ppq.data.worker",
               "--stage", stage, "--source", source,
               "--shard", str(shard), "--num-shards", str(N_GPUS),
               "--out", str(TOKENS_DIR), "--log-dir", str(LOG_DIR),
               "--data-root", str(DATA_ROOT),
               "--mimi-weight", MIMI_WEIGHT, "--tokenizer", QWEN_TOKENIZER,
               "--asr-model", ASR_MODEL, "--device", "cuda",
               "--max-attempts", str(MAX_ATTEMPTS), *extra_args]
        gpu = shard % N_PHYSICAL_GPUS  # share GPUs when shards > physical GPUs
        subprocess.Popen(cmd, env={**os.environ, "CUDA_VISIBLE_DEVICES": str(gpu)},
                         stdout=console, stderr=subprocess.STDOUT,
                         start_new_session=True)
        launched.append(shard)
    print(f"{stage}/{source}: launched shards {launched} | already running {running}")
"""))

HF_CELLS.append(md("""
## 3. ASR cache warm-up (task sets only)

The CC-BY task sets ship without transcripts, so Whisper runs over energy-VAD
speech regions first and caches word timestamps under
`DATA_ROOT/asr_cache/<source>/<session>/ch<k>.json`. video-21h (bundled
transcripts) and turn-104h (SRT + inline ASR in the real stage) need nothing
here. Fully cached sessions are skipped, so this stage is resumable and can
run while earlier shards are still going.
"""))

HF_CELLS.append(code("""
from ppq.data.oto_sources import SOURCES

ASR_SOURCES = [s for s in SELECTED_SOURCES if SOURCES[s].asr_mode == "full"]
asr_stages = tuple(f"asr-{s}" for s in ASR_SOURCES)
if not ASR_SOURCES:
    print("no selected source needs the asr stage")
elif pipeline_all_done(LOG_DIR, asr_stages):
    print("asr stage already complete")
    print(render_data_progress(LOG_DIR, asr_stages))
else:
    for s in ASR_SOURCES:
        launch_hf_workers("asr", s)
"""))

HF_CELLS.append(code("""
# Live progress - refreshes until all asr shards finish.
# Interrupt the cell to stop watching (workers keep running); re-run any time.
from ppq.progress import watch
if ASR_SOURCES:
    watch(LOG_DIR, asr_stages, interval_s=60)
"""))

HF_CELLS.append(md("""
## 4. Real-conversation tokenization

Streams each session (HTTP range reads - no full tar downloads), resamples to
24 kHz stereo, loudness-normalizes, checks channel separation, cuts 20-80 s
chunks at mutual silence, and writes one sample per chunk x role (each
speaker gets a turn as the agent). turn-104h raw WAVs are deleted after each
session (keep them with `--keep-raw` in `extra_args`).
"""))

HF_CELLS.append(code("""
real_stages = tuple(f"real-{s}" for s in SELECTED_SOURCES)
if pipeline_all_done(LOG_DIR, real_stages):
    print("real stage already complete")
    print(render_data_progress(LOG_DIR, real_stages))
else:
    for s in SELECTED_SOURCES:
        launch_hf_workers("real", s)
"""))

HF_CELLS.append(code("""
# Live progress - refreshes until all real shards finish (this is the long one).
from ppq.progress import watch
watch(LOG_DIR, real_stages, interval_s=120)
"""))

HF_CELLS.append(code("""
# Last lines of each shard log (failures show up here with a full traceback).
for s in SELECTED_SOURCES:
    for shard in range(N_GPUS):
        p = LOG_DIR / f"worker-real-{s}-{shard:04d}.log"
        if p.exists():
            lines = p.read_text(encoding="utf-8", errors="replace").splitlines()
            print(f"--- {s} shard {shard} (last 2 lines) ---")
            print(chr(10).join(lines[-2:]))
"""))

HF_CELLS.append(md("""
## 5. Validation

Format-checks a sample of every real manifest (shapes, dtypes, token ranges,
0/1 loss mask, supervised agent frames), then pulls real batches through a
tiny PPQ model + the real training loss on CPU.
"""))

HF_CELLS.append(code("""
from ppq.config import PPQModelConfig, TrainConfig
from ppq.data.validate import check_manifest, loader_smoke

cfg = PPQModelConfig()
real_manifests = sorted(TOKENS_DIR.glob("manifest-real-*.jsonl"))
assert real_manifests, "no real manifests yet - run the real stage first"
for m in real_manifests:
    rep = check_manifest(m, cfg, segment_frames=1250)
    print(f"{m.name}: {rep['entries']} samples, {rep['hours']} h, "
          f"{rep['duplicate_names']} dupes, {len(rep['errors'])} errors "
          f"({rep['checked']} checked)")
    for e in rep["errors"][:5]:
        print("   ", e)

tcfg = TrainConfig(model=cfg, segment_frames=1250)
losses = loader_smoke([str(m) for m in real_manifests], tcfg,
                      n_batches=2, batch_size=2)
print("loader smoke losses:", {k: round(v, 3) for k, v in losses.items()})
"""))

HF_CELLS.append(md("""
## 6. Aggregate stats
"""))

HF_CELLS.append(code("""
from ppq.progress import read_jsonl, repair_jsonl

per_source = {}
for m in sorted(TOKENS_DIR.glob("manifest-real-*.jsonl")):
    repair_jsonl(m)
    for e in read_jsonl(m):
        d = per_source.setdefault(e.get("source", "?"), [0, 0.0])
        d[0] += 1
        d[1] += e.get("duration_s", e["frames"] / 12.5)
for src, (n, sec) in sorted(per_source.items()):
    print(f"{src:<28} {n:>6} samples {sec / 3600:>8.1f} h")
print(f"{'TOTAL':<28} {sum(v[0] for v in per_source.values()):>6} samples "
      f"{sum(v[1] for v in per_source.values()) / 3600:>8.1f} h")
"""))

HF_CELLS.append(md("""
## 7. Listen to a sample

Decodes one sample's agent/user code rows back to audio with Mimi.
"""))

HF_CELLS.append(code("""
import numpy as np
import IPython.display as ipd
from ppq.checkpoint import get_mimi
from ppq.data.validate import decode_channels
from ppq.progress import read_jsonl

mimi = get_mimi(MIMI_WEIGHT, "cuda")
first = read_jsonl(real_manifests[0])[0]
codes = np.load(first["path"])["codes"]
agent, user = decode_channels(mimi, codes)
print(first.get("name", first["path"]), "| source:", first.get("source"))
ipd.display(ipd.Audio(agent, rate=24000))
ipd.display(ipd.Audio(user, rate=24000))
"""))


# ===========================================================================

NB_DIR.mkdir(parents=True, exist_ok=True)
for name, cells in (("ppq_data_pipeline.ipynb", DATA_CELLS),
                    ("ppq_training.ipynb", TRAIN_CELLS),
                    ("ppq_huggingface_data_pipeline.ipynb", HF_CELLS)):
    path = NB_DIR / name
    with open(path, "w", encoding="utf-8") as f:
        json.dump(notebook(cells), f, indent=1, ensure_ascii=False)
    print("wrote", path, f"({len(cells)} cells)")

