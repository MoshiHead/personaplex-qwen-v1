"""PPQ training stack."""
